import { Heart, Calendar, Sparkles, Star } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"

export default function RomanticSite() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-pink-50 to-red-50">
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center px-4 overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-20 left-10 text-rose-200 animate-pulse">
            <Heart className="w-8 h-8" />
          </div>
          <div className="absolute top-40 right-20 text-pink-200 animate-pulse delay-1000">
            <Star className="w-6 h-6" />
          </div>
          <div className="absolute bottom-40 left-20 text-rose-300 animate-pulse delay-2000">
            <Sparkles className="w-10 h-10" />
          </div>
          <div className="absolute bottom-20 right-10 text-pink-300 animate-pulse delay-500">
            <Heart className="w-12 h-12" />
          </div>
        </div>

        <div className="max-w-4xl mx-auto text-center relative z-10">
          {/* Date Badge */}
          <div className="inline-flex items-center gap-2 bg-white/80 backdrop-blur-sm rounded-full px-6 py-3 mb-8 shadow-lg border border-rose-200">
            <Calendar className="w-5 h-5 text-rose-500" />
            <span className="text-rose-700 font-medium">18 de dezembro de 2024</span>
          </div>

          {/* Main Message */}
          <div className="space-y-6">
            <h1 className="text-6xl md:text-8xl font-bold text-rose-600 mb-4 animate-fade-in">SIM</h1>

            <p className="text-xl md:text-2xl text-rose-700 font-light leading-relaxed max-w-2xl mx-auto">
              finalmente...
            </p>

            <div className="bg-white/90 backdrop-blur-sm rounded-2xl p-8 md:p-12 shadow-xl border border-rose-100 max-w-3xl mx-auto">
              <Heart className="w-12 h-12 text-rose-500 mx-auto mb-6 animate-pulse" />
              <p className="text-lg md:text-xl text-gray-700 leading-relaxed italic">
                "Eu te amo, não importa a dificuldade que iremos passar, nunca esqueça disso, achei a menina pelo qual
                meu coração acelera mais rápido"
              </p>
            </div>
          </div>

          {/* Decorative hearts */}
          <div className="flex justify-center gap-4 mt-12">
            <Heart className="w-6 h-6 text-rose-400 animate-bounce" />
            <Heart className="w-8 h-8 text-rose-500 animate-bounce delay-100" />
            <Heart className="w-6 h-6 text-rose-400 animate-bounce delay-200" />
          </div>
        </div>
      </section>

      {/* Love Story Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-rose-600 mb-4">Nossa História de Amor</h2>
            <p className="text-xl text-rose-700 max-w-2xl mx-auto">
              Cada momento juntos é uma página especial em nossa história
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="bg-white/80 backdrop-blur-sm border-rose-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Heart className="w-8 h-8 text-rose-500" />
                </div>
                <h3 className="text-xl font-semibold text-rose-700 mb-4">Primeiro Encontro</h3>
                <p className="text-gray-600">
                  O momento em que nossos olhares se cruzaram e soubemos que algo especial estava começando
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-rose-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-8 h-8 text-rose-500" />
                </div>
                <h3 className="text-xl font-semibold text-rose-700 mb-4">Momentos Mágicos</h3>
                <p className="text-gray-600">
                  Cada risada compartilhada, cada conversa até tarde, cada momento que nos aproximou mais
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/80 backdrop-blur-sm border-rose-200 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8 text-center">
                <div className="w-16 h-16 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Star className="w-8 h-8 text-rose-500" />
                </div>
                <h3 className="text-xl font-semibold text-rose-700 mb-4">Nosso Futuro</h3>
                <p className="text-gray-600">
                  Juntos, prontos para enfrentar qualquer desafio e criar memórias inesquecíveis
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Promise Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-rose-100 to-pink-100">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-rose-200">
            <Heart className="w-16 h-16 text-rose-500 mx-auto mb-8 animate-pulse" />
            <h2 className="text-3xl md:text-4xl font-bold text-rose-600 mb-8">Minha Promessa Para Você</h2>
            <div className="space-y-6 text-lg text-gray-700">
              <p className="italic">
                "Prometo estar ao seu lado em todos os momentos, nos dias de sol e nos dias de chuva."
              </p>
              <p className="italic">"Prometo te amar com toda a intensidade do meu coração, hoje e sempre."</p>
              <p className="italic">
                "Prometo que juntos construiremos uma história linda, cheia de amor, cumplicidade e felicidade."
              </p>
            </div>
            <div className="flex justify-center gap-2 mt-8">
              {[...Array(5)].map((_, i) => (
                <Heart
                  key={i}
                  className="w-6 h-6 text-rose-400 animate-pulse"
                  style={{ animationDelay: `${i * 200}ms` }}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 text-center">
        <div className="max-w-2xl mx-auto">
          <div className="flex justify-center gap-3 mb-6">
            <Heart className="w-8 h-8 text-rose-500 animate-pulse" />
            <Heart className="w-10 h-10 text-rose-600 animate-pulse delay-300" />
            <Heart className="w-8 h-8 text-rose-500 animate-pulse delay-600" />
          </div>
          <p className="text-rose-600 text-lg font-medium">Para sempre e sempre... 💕</p>
          <p className="text-rose-500 mt-2">18 de dezembro de 2024 - O dia que mudou nossas vidas</p>
        </div>
      </footer>
    </div>
  )
}
